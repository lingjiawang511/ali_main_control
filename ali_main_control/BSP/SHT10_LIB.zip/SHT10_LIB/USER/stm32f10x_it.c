/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include"HeadType.h"
#include "usart.h"
#include "sht1x.h"

/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
}
//=============================================================================
//��������:TIM2_IRQHandler
//���ܸ�Ҫ:TIM2 �жϺ���
//����˵��:��
//��������:��
//=============================================================================
void TIM2_IRQHandler(void)
{
	if ( TIM_GetITStatus(TIM2 , TIM_IT_Update) != RESET ) 
	{	
		Led_Flash();
		Belt_Control();
		Key_Light_Dispose();

    if(Group_Check_Time > 0){
      Group_Check_Time--;
    }
		if(sht10_read_time > 0){
			sht10_read_time--;
		}	
		
		TIM_ClearITPendingBit(TIM2 , TIM_FLAG_Update);  		 
	}		 	
}
//=============================================================================
//��������:TIM3_IRQHandler
//���ܸ�Ҫ:TIM3 �жϺ���
//����˵��:��
//��������:��
//=============================================================================
void TIM3_IRQHandler(void)
{
	if ( TIM_GetITStatus(TIM3 , TIM_IT_Update) != RESET ) 
	{	
        if (1 == Usart1_Control_Data.rx_start){
            if(Auto_Frame_Time1 >0){
                Auto_Frame_Time1--;
            }else{
                Auto_Frame_Time1 = 0;
                Usart1_Control_Data.rx_aframe = 1; 
                Usart1_Control_Data.rx_count = Usart1_Control_Data.rx_index;
                Usart1_Control_Data.rx_start = 0;
                Usart1_Control_Data.rx_index = 0;
            }
        }
				if (1 == Usart2_Control_Data.rx_start){
            if(Auto_Frame_Time2 >0){
                Auto_Frame_Time2--;
            }else{
                Auto_Frame_Time2 = 0;
                Usart2_Control_Data.rx_aframe = 1; 
                Usart2_Control_Data.rx_count = Usart3_Control_Data.rx_index;
                Usart2_Control_Data.rx_start = 0;
                Usart2_Control_Data.rx_index = 0;
            }
        }
				if (1 == Usart3_Control_Data.rx_start){
            if(Auto_Frame_Time3 >0){
                Auto_Frame_Time3--;
            }else{
                Auto_Frame_Time3 = 0;
                Usart3_Control_Data.rx_aframe = 1; 
                Usart3_Control_Data.rx_count = Usart3_Control_Data.rx_index;
                Usart3_Control_Data.rx_start = 0;
                Usart3_Control_Data.rx_index = 0;
            }
        }
				if (1 == Usart4_Control_Data.rx_start){
            if(Auto_Frame_Time4 >0){
                Auto_Frame_Time4--;
            }else{
                Auto_Frame_Time4 = 0;
                Usart4_Control_Data.rx_aframe = 1; 
                Usart4_Control_Data.rx_count = Usart4_Control_Data.rx_index;
                Usart4_Control_Data.rx_start = 0;
                Usart4_Control_Data.rx_index = 0;
            }
        }
			Input_pulse_IRQTimer();    //����ͨ������������
      TIM_ClearITPendingBit(TIM3 , TIM_FLAG_Update);     
	}		 	
}

//=============================================================================
//��������:USART1_IRQHandler
//���ܸ�Ҫ:USART1 �жϺ���
//����˵��:��
//��������:��
//=============================================================================
void USART1_IRQHandler(void)
{
  
	if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE)||USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET){ //�������û������һֱ���жϵ�����
       USART1_Do_Rx(USART_ReceiveData(USART1));
       USART_ClearFlag(USART1,USART_FLAG_RXNE);
	}
	if(USART_GetFlagStatus(USART1, USART_FLAG_TC)){
       USART1_Do_Tx();
       USART_ClearFlag(USART1,USART_FLAG_TC);
	}
}
//=============================================================================
//��������:USART2_IRQHandler
//���ܸ�Ҫ:USART2 �жϺ���
//����˵��:��
//��������:��
//=============================================================================
void USART2_IRQHandler(void)
{
  
	if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE)||USART_GetFlagStatus(USART2, USART_FLAG_ORE) != RESET){ //�������û������һֱ���жϵ�����
       USART2_Do_Rx(USART_ReceiveData(USART1));
       USART_ClearFlag(USART2,USART_FLAG_RXNE);
	}
	if(USART_GetFlagStatus(USART2, USART_FLAG_TC)){
       USART2_Do_Tx();
       USART_ClearFlag(USART2,USART_FLAG_TC);
	}
}
//=============================================================================
//��������:USART3_IRQHandler
//���ܸ�Ҫ:USART3 �жϺ���
//����˵��:��
//��������:��
//=============================================================================
void USART3_IRQHandler(void)
{
  
	if(USART_GetFlagStatus(USART3, USART_FLAG_RXNE)||USART_GetFlagStatus(USART3, USART_FLAG_ORE) != RESET){ //�������û������һֱ���жϵ�����
       USART3_Do_Rx(USART_ReceiveData(USART3));
       USART_ClearFlag(USART3,USART_FLAG_RXNE);
	}
	if(USART_GetFlagStatus(USART3, USART_FLAG_TC)){
       USART3_Do_Tx();
       USART_ClearFlag(USART3,USART_FLAG_TC);
	}
}
//=============================================================================
//��������:USART1_IRQHandler
//���ܸ�Ҫ:USART1 �жϺ���
//����˵��:��
//��������:��
//=============================================================================
void UART4_IRQHandler(void)
{
  
	if(USART_GetFlagStatus(UART4, USART_FLAG_RXNE)||USART_GetFlagStatus(UART4, USART_FLAG_ORE) != RESET){ //�������û������һֱ���жϵ�����
       USART4_Do_Rx(USART_ReceiveData(UART4));
       USART_ClearFlag(UART4,USART_FLAG_RXNE);
	}
	if(USART_GetFlagStatus(UART4, USART_FLAG_TC)){
       USART4_Do_Tx();
       USART_ClearFlag(UART4,USART_FLAG_TC);
	}
}


