#ifndef __EXTI_H
#define __EXIT_H	 

 	 
void EXTIX_Init(void);//�ⲿ�жϳ�ʼ��
void 	Input_pulse_IRQTimer(void);

#endif








